# Game Perf Lab

Android app (Kotlin + Jetpack Compose) that records device temperature, battery drain, thermal status
and free RAM while you play a game, then compares graphics settings per game. Sessions export to CSV
so data from many phones can be pooled for the thesis analysis.

## Working now
- Record tab: game name + in-game graphics preset + FPS setting, foreground service, optional overlay
- Sessions tab: list, per-session stats and charts, CSV export, delete
- Compare tab: groups sessions by game/preset/fps and picks the coolest + most battery-friendly setting (placeholder score)

## Not done yet (thesis work)
1. FPS of the game: implement `monitor/FpsSource.kt` (e.g. Shizuku + `dumpsys SurfaceFlinger --latency`).
2. Central database (Firebase/Supabase) instead of manual CSV merging.
3. A real recommender: train on pooled CSVs (kNN / regression) and replace `score()` in CompareScreen.kt.
4. Evaluation: collect 10-20 phones x 2-3 games; compare default vs recommended settings.

## Notes
- Battery temperature is a proxy for device heat. Battery level is whole percent, so drain is coarse on short sessions.
- `current_ma` unit/sign varies by manufacturer.
