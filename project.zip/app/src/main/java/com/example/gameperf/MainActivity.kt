package com.example.gameperf

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.gameperf.model.Session
import com.example.gameperf.ui.CompareScreen
import com.example.gameperf.ui.RecordScreen
import com.example.gameperf.ui.SessionDetail
import com.example.gameperf.ui.SessionsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            ) { AppRoot() }
        }
    }
}

@Composable
fun AppRoot() {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Session?>(null) }
    BackHandler(enabled = open != null) { open = null }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0; open = null },
                    icon = { Icon(Icons.Default.PlayArrow, null) }, label = { Text("บันทึก") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1; open = null },
                    icon = { Icon(Icons.Default.History, null) }, label = { Text("เซสชัน") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2; open = null },
                    icon = { Icon(Icons.Default.BarChart, null) }, label = { Text("เปรียบเทียบ") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            val o = open
            if (o != null) {
                SessionDetail(o, onBack = { open = null })
            } else when (tab) {
                0 -> RecordScreen()
                1 -> SessionsScreen { open = it }
                else -> CompareScreen()
            }
        }
    }
}
