package com.example.gameperf.data

import android.content.Context
import com.example.gameperf.model.Sample
import com.example.gameperf.model.Session
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class SessionStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "sessions").apply { mkdirs() }

    fun save(s: Session) {
        val o = JSONObject().apply {
            put("id", s.id); put("startMs", s.startMs); put("game", s.game)
            put("preset", s.preset); put("fpsSetting", s.fpsSetting)
            put("device", s.device); put("sdk", s.androidSdk)
            val arr = JSONArray()
            s.samples.forEach {
                arr.put(JSONArray().put(it.t).put(it.tempC.toDouble()).put(it.batteryPct.toDouble())
                    .put(it.thermal).put(it.availRamMb).put(it.currentMa.toDouble()).put(it.fps.toDouble()))
            }
            put("samples", arr)
        }
        File(dir, "${s.id}.json").writeText(o.toString())
    }

    fun loadAll(): List<Session> =
        (dir.listFiles { f -> f.extension == "json" } ?: emptyArray())
            .mapNotNull { f -> runCatching { parse(JSONObject(f.readText())) }.getOrNull() }
            .sortedByDescending { it.startMs }

    fun delete(id: String) { File(dir, "$id.json").delete() }

    /** One row per second, with session info repeated on every row so files from many phones can be merged. */
    fun exportCsv(s: Session): File {
        val out = File(ctx.cacheDir, "export").apply { mkdirs() }
        val f = File(out, "session_${s.id}.csv")
        val sb = StringBuilder("session_id,device,android_sdk,game,preset,fps_setting,t_sec,temp_c,battery_pct,thermal,avail_ram_mb,current_ma,fps\n")
        val game = s.game.replace(",", " ")
        val device = s.device.replace(",", " ")
        s.samples.forEach {
            sb.append("${s.id},$device,${s.androidSdk},$game,${s.preset},${s.fpsSetting},")
            sb.append("${it.t},${it.tempC},${it.batteryPct},${it.thermal},${it.availRamMb},${it.currentMa},${it.fps}\n")
        }
        f.writeText(sb.toString())
        return f
    }

    private fun parse(o: JSONObject): Session {
        val arr = o.getJSONArray("samples")
        val samples = (0 until arr.length()).map {
            val a = arr.getJSONArray(it)
            Sample(a.getInt(0), a.getDouble(1).toFloat(), a.getDouble(2).toFloat(), a.getInt(3),
                a.getInt(4), a.getDouble(5).toFloat(), a.getDouble(6).toFloat())
        }
        return Session(o.getString("id"), o.getLong("startMs"), o.getString("game"),
            o.getString("preset"), o.getInt("fpsSetting"), o.getString("device"), o.getInt("sdk"), samples)
    }
}
