package com.example.gameperf.model

/** One reading per second. fps = -1 when not available. */
data class Sample(
    val t: Int,
    val tempC: Float,
    val batteryPct: Float,
    val thermal: Int,
    val availRamMb: Int,
    val currentMa: Float,
    val fps: Float,
)

data class Session(
    val id: String,
    val startMs: Long,
    val game: String,
    val preset: String,
    val fpsSetting: Int,
    val device: String,
    val androidSdk: Int,
    val samples: List<Sample>,
) {
    val durationSec: Int get() = samples.lastOrNull()?.t ?: 0
    val avgTemp: Float get() = if (samples.isEmpty()) 0f else samples.map { it.tempC }.average().toFloat()
    val maxTemp: Float get() = samples.maxOfOrNull { it.tempC } ?: 0f
    val tempRise: Float get() = if (samples.size < 2) 0f else samples.last().tempC - samples.first().tempC
    val maxThermal: Int get() = samples.maxOfOrNull { it.thermal } ?: 0
    val avgFps: Float get() {
        val f = samples.filter { it.fps >= 0 }
        return if (f.isEmpty()) -1f else f.map { it.fps }.average().toFloat()
    }
    /** Battery percentage points lost per minute (battery level is whole numbers, so this is coarse). */
    val drainPerMin: Float get() {
        val a = samples.firstOrNull { it.batteryPct >= 0 }
        val b = samples.lastOrNull { it.batteryPct >= 0 }
        if (a == null || b == null || durationSec < 60) return 0f
        return (a.batteryPct - b.batteryPct) / (durationSec / 60f)
    }
}
