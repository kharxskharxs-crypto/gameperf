package com.example.gameperf.monitor

/**
 * Where FPS of the *game* comes from. Returns -1 when unavailable.
 *
 * Android does not let a normal app read another app's frame rate. Typical solutions:
 *  - Shizuku (or adb-granted permission) to run `dumpsys SurfaceFlinger --latency <layer>` and compute FPS
 *  - Android's Game Mode / Performance Hint APIs (limited info)
 * Implement FpsSource with one of those and pass it to MonitorService (see README).
 */
interface FpsSource { fun currentFps(): Float }

class NoFpsSource : FpsSource { override fun currentFps(): Float = -1f }
