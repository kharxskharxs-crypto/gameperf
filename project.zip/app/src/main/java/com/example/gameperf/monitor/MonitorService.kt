package com.example.gameperf.monitor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import com.example.gameperf.data.SessionStore
import com.example.gameperf.model.Sample
import com.example.gameperf.model.Session
import com.example.gameperf.ui.thermalName
import java.util.UUID

class MonitorService : Service() {

    companion object {
        const val ACTION_START = "com.example.gameperf.START"
        const val ACTION_STOP = "com.example.gameperf.STOP"
        const val EX_GAME = "game"
        const val EX_PRESET = "preset"
        const val EX_FPS = "fps"
        private const val CHANNEL = "monitor"
        private const val NOTIF_ID = 1
        val running = mutableStateOf(false)
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var sampler: SystemSampler
    private val fpsSource: FpsSource = NoFpsSource() // TODO: plug in a real FPS source (see README)
    private val samples = mutableListOf<Sample>()
    private var overlay: TextView? = null
    private var tick = 0
    private var startMs = 0L
    private var game = ""
    private var preset = ""
    private var fpsSetting = 60
    private var finished = false

    private val loop = object : Runnable {
        override fun run() {
            val s = sampler.sample(tick, fpsSource.currentFps())
            samples.add(s)
            tick++
            updateOverlay(s)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finishSession()
            return START_NOT_STICKY
        }
        if (running.value) return START_NOT_STICKY

        game = intent?.getStringExtra(EX_GAME)?.ifBlank { null } ?: "Unknown"
        preset = intent?.getStringExtra(EX_PRESET) ?: "Medium"
        fpsSetting = intent?.getIntExtra(EX_FPS, 60) ?: 60
        sampler = SystemSampler(this)
        startMs = System.currentTimeMillis()

        startInForeground()
        addOverlay()
        running.value = true
        handler.post(loop)
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Monitoring", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Game Perf Lab")
            .setContentText("Recording: $game")
            .setOngoing(true)
            .addAction(0, "Stop", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            text = "Game Perf Lab..."
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 80 }
        wm.addView(tv, lp)
        overlay = tv
    }

    private fun removeOverlay() {
        overlay?.let {
            runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }
        }
        overlay = null
    }

    private fun updateOverlay(s: Sample) {
        val fpsText = if (s.fps >= 0) "%.0f".format(s.fps) else "n/a"
        overlay?.text = "%.1f°C  %s\nBAT %.0f%%  RAM %d MB\nFPS %s  t=%ds".format(
            s.tempC, thermalName(s.thermal), s.batteryPct, s.availRamMb, fpsText, s.t
        )
    }

    private fun finishSession() {
        if (finished) return
        finished = true
        handler.removeCallbacks(loop)
        removeOverlay()
        if (running.value && samples.size >= 5) {
            SessionStore(this).save(
                Session(
                    id = UUID.randomUUID().toString().take(8),
                    startMs = startMs, game = game, preset = preset, fpsSetting = fpsSetting,
                    device = "${Build.MANUFACTURER} ${Build.MODEL}", androidSdk = Build.VERSION.SDK_INT,
                    samples = samples.toList()
                )
            )
        }
        running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        finishSession()
        super.onDestroy()
    }
}
