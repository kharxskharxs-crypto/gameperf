package com.example.gameperf.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.gameperf.model.Sample

class SystemSampler(private val ctx: Context) {
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun sample(t: Int, fps: Float): Sample {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100f / scale else -1f

        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // Unit and sign differ between phones; stored as raw/1000 for later analysis.
        val currentMa = if (raw == Int.MIN_VALUE) 0f else raw / 1000f

        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) pm.currentThermalStatus else 0

        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val availMb = (mi.availMem / 1048576L).toInt()

        return Sample(t, temp, pct, thermal, availMb, currentMa, fps)
    }
}
