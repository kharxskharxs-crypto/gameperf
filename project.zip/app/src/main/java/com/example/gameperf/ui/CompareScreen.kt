package com.example.gameperf.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.gameperf.data.SessionStore
import com.example.gameperf.model.Session

private data class CmpRow(val preset: String, val fps: Int, val n: Int, val avgTemp: Float,
                       val maxTemp: Float, val drain: Float, val thermal: Int, val score: Float)

/**
 * Placeholder "recommender": lower score = cooler, lighter on battery.
 * Replace with the model you evaluate in the thesis (rules, kNN, regression on pooled data).
 */
private fun score(maxTemp: Float, drain: Float, thermal: Int) = maxTemp + drain * 3f + thermal * 2f

@Composable
fun CompareScreen() {
    val ctx = LocalContext.current
    // Only sessions of at least 2 minutes are comparable.
    val sessions = remember { SessionStore(ctx).loadAll().filter { it.durationSec >= 120 } }

    if (sessions.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("ต้องมีเซสชันที่ยาวอย่างน้อย 2 นาที เพื่อเปรียบเทียบค่ากราฟิก")
        }
        return
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("เปรียบเทียบค่ากราฟิกต่อเกม", style = MaterialTheme.typography.titleLarge)
        sessions.groupBy { it.game }.forEach { (game, gs) ->
            val rows = gs.groupBy { it.preset to it.fpsSetting }.map { (k, ss) ->
                val maxT = ss.map { it.maxTemp }.average().toFloat()
                val drain = ss.map { it.drainPerMin }.average().toFloat()
                val th = ss.maxOf { it.maxThermal }
                CmpRow(k.first, k.second, ss.size, ss.map { it.avgTemp }.average().toFloat(), maxT, drain, th,
                    score(maxT, drain, th))
            }.sortedBy { it.score }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(game, style = MaterialTheme.typography.titleMedium)
                    rows.forEach { r ->
                        Text("${r.preset} · ${r.fps} fps (${r.n} เซสชัน): เฉลี่ย %.1f°C, สูงสุด %.1f°C, แบต %.2f%%/นาที, thermal ${thermalName(r.thermal)}"
                            .format(r.avgTemp, r.maxTemp, r.drain), style = MaterialTheme.typography.bodySmall)
                    }
                    if (rows.size >= 2) {
                        val best = rows.first()
                        Text("เย็นและประหยัดแบตที่สุด: ${best.preset} · ${best.fps} fps",
                            style = MaterialTheme.typography.labelLarge)
                    } else {
                        Text("ลองวัดเพิ่มด้วยค่ากราฟิกอื่น เพื่อเปรียบเทียบ", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
