package com.example.gameperf.ui

fun thermalName(i: Int): String = when (i) {
    0 -> "NONE"
    1 -> "LIGHT"
    2 -> "MODERATE"
    3 -> "SEVERE"
    4 -> "CRITICAL"
    5 -> "EMERGENCY"
    6 -> "SHUTDOWN"
    else -> "?"
}

fun fmtDuration(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)
