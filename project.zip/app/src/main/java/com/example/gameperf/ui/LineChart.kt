package com.example.gameperf.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun LineChart(title: String, values: List<Float>, unit: String, modifier: Modifier = Modifier) {
    val pts = if (values.size > 600) {
        val step = values.size / 600 + 1
        values.filterIndexed { i, _ -> i % step == 0 }
    } else values
    val min = pts.minOrNull() ?: 0f
    val max = pts.maxOrNull() ?: 0f
    val color = MaterialTheme.colorScheme.primary

    Column(modifier) {
        Text("$title  (${"%.1f".format(min)} – ${"%.1f".format(max)} $unit)", style = MaterialTheme.typography.labelLarge)
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            if (pts.size < 2) return@Canvas
            val range = (max - min).coerceAtLeast(0.1f)
            val path = Path()
            pts.forEachIndexed { i, v ->
                val x = size.width * i / (pts.size - 1)
                val y = size.height - (v - min) / range * size.height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = 4f))
        }
    }
}
