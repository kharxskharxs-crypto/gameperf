package com.example.gameperf.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.gameperf.monitor.MonitorService

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecordScreen() {
    val ctx = LocalContext.current
    var game by remember { mutableStateOf("") }
    var preset by remember { mutableStateOf("Medium") }
    var fps by remember { mutableStateOf(60) }
    val running by MonitorService.running

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Game Perf Lab", style = MaterialTheme.typography.headlineSmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("วิธีใช้", style = MaterialTheme.typography.titleSmall)
                Text("1) ใส่ชื่อเกมและค่ากราฟิกที่ตั้งไว้ในเกม  2) กดเริ่มบันทึก  3) เปิดเกมแล้วเล่นอย่างน้อย 10 นาที  4) กลับมากดหยุด (หรือกด Stop ที่แจ้งเตือน)")
            }
        }

        OutlinedTextField(
            value = game, onValueChange = { game = it },
            label = { Text("ชื่อเกม") }, singleLine = true,
            enabled = !running, modifier = Modifier.fillMaxWidth()
        )

        Text("ค่ากราฟิกในเกม", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Low", "Medium", "High", "Ultra").forEach {
                FilterChip(selected = preset == it, onClick = { if (!running) preset = it }, label = { Text(it) })
            }
        }

        Text("ตั้ง FPS ในเกม", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(30, 60, 90, 120).forEach {
                FilterChip(selected = fps == it, onClick = { if (!running) fps = it }, label = { Text("$it") })
            }
        }

        Spacer(Modifier.height(4.dp))

        if (!running) {
            Button(
                onClick = {
                    val i = Intent(ctx, MonitorService::class.java)
                        .setAction(MonitorService.ACTION_START)
                        .putExtra(MonitorService.EX_GAME, game.trim())
                        .putExtra(MonitorService.EX_PRESET, preset)
                        .putExtra(MonitorService.EX_FPS, fps)
                    ContextCompat.startForegroundService(ctx, i)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("เริ่มบันทึก") }
        } else {
            Button(
                onClick = {
                    ctx.startService(Intent(ctx, MonitorService::class.java).setAction(MonitorService.ACTION_STOP))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("หยุดและบันทึกเซสชัน") }
            Text("กำลังบันทึกอยู่... สลับไปเปิดเกมได้เลย", style = MaterialTheme.typography.bodyMedium)
        }

        if (!Settings.canDrawOverlays(ctx)) {
            OutlinedButton(
                onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("อนุญาตแสดงตัวเลขลอยบนจอ (overlay)") }
            Text("ไม่อนุญาตก็บันทึกได้ แค่ไม่เห็นตัวเลขลอยบนหน้าจอเกม", style = MaterialTheme.typography.bodySmall)
        }
    }
}
