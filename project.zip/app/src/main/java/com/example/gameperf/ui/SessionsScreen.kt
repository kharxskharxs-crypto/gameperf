package com.example.gameperf.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.gameperf.data.SessionStore
import com.example.gameperf.model.Session
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun dateText(ms: Long) = SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(ms))

@Composable
fun SessionsScreen(onOpen: (Session) -> Unit) {
    val ctx = LocalContext.current
    val list = remember { SessionStore(ctx).loadAll() }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("ยังไม่มีเซสชัน ไปแท็บ “บันทึก” เพื่อเริ่มวัด")
        }
        return
    }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list, key = { it.id }) { s ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(s) }) {
                Column(Modifier.padding(14.dp)) {
                    Text(s.game, style = MaterialTheme.typography.titleMedium)
                    Text("${s.preset} · ${s.fpsSetting} fps · ${fmtDuration(s.durationSec)} นาที")
                    Text("เฉลี่ย %.1f°C · สูงสุด %.1f°C".format(s.avgTemp, s.maxTemp), style = MaterialTheme.typography.bodySmall)
                    Text(dateText(s.startMs) + " · " + s.device, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SessionDetail(session: Session, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SessionStore(ctx) }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ กลับ") }
        }
        Text(session.game, style = MaterialTheme.typography.headlineSmall)
        Text("${session.preset} · ${session.fpsSetting} fps · ${fmtDuration(session.durationSec)} นาที")
        Text(session.device + " (Android SDK ${session.androidSdk})", style = MaterialTheme.typography.bodySmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("อุณหภูมิเฉลี่ย %.1f°C   สูงสุด %.1f°C".format(session.avgTemp, session.maxTemp))
                Text("อุณหภูมิเพิ่มขึ้น %.1f°C".format(session.tempRise))
                Text("แบตลด %.2f %% / นาที".format(session.drainPerMin))
                Text("Thermal สูงสุด: ${thermalName(session.maxThermal)}")
                Text(if (session.avgFps >= 0) "FPS เฉลี่ย %.1f".format(session.avgFps) else "FPS: ไม่มีข้อมูล (ยังไม่ได้เชื่อมตัววัด FPS)")
            }
        }

        LineChart("อุณหภูมิแบต", session.samples.map { it.tempC }, "°C", Modifier.fillMaxWidth())
        LineChart("RAM ว่าง", session.samples.map { it.availRamMb.toFloat() }, "MB", Modifier.fillMaxWidth())
        LineChart("กระแสแบต", session.samples.map { it.currentMa }, "mA", Modifier.fillMaxWidth())
        if (session.avgFps >= 0) {
            LineChart("FPS", session.samples.map { it.fps }, "fps", Modifier.fillMaxWidth())
        }

        Button(
            onClick = {
                val file = store.exportCsv(session)
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "ส่งออก CSV"))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ส่งออกเป็น CSV") }

        OutlinedButton(
            onClick = { store.delete(session.id); onBack() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ลบเซสชันนี้") }
    }
}
